rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page0001-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page0001" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page0001-layer-text8114317" style="position: absolute; left: 40px; top: 70px; width: 410px; height: 47px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8114317" data-stencil-id="text8114317">\
         <div title="">\
            <div style="height: 52px;width:420px;font-size:2.67em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Research &amp; analytics firm<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-link6989249" style="position: absolute; left: 60px; top: 120px; width: 6px; height: 19px" data-interactive-element-type="default.link" class="link stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link6989249" data-stencil-id="link6989249">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 19px;width:11px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;"> <br /></a></div>\
      </div>\
      <div id="__containerId__-page0001-layer-tabbutton7384848" style="position: absolute; left: 50px; top: 160px; width: 72px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton7384848" data-stencil-id="tabbutton7384848">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:82px;" width="72" height="25">\
               <svg:g id="targetpage5012072" x="-5" y="0" width="72" height="20" name="targetpage5012072" class="">\
                  <svg:path id="__containerId__-page0001-layer-tabbutton7384848_small_path" width="72" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 67,5 C 77,5 77,15 77,15 L 77,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page0001-layer-tabbutton7384848_big_path" width="72" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 67,0 C 77,0 77,10 77,10 L 77,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page0001-layer-tabbutton7384848div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:72px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page0001-layer-tabbutton7384848\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page0001-layer-tabbutton7384848\', \'result\');">\
               				Solutions\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page0001-layer-tabbutton7384848\', \'interaction3082325\', \
		{\
		\
			\'id\': \'action4336758\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction9203426\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page5012072\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page0001-layer-image1326933" style="position: absolute; left: 0px; top: 190px; width: 960px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image1326933" data-stencil-id="image1326933">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 145px;width:960px;" width="960" height="145" viewBox="0 0 960 145">\
               <svg:g width="960" height="145">\
                  <svg:svg x="0" y="0" width="960" height="145">\
                     <svg:image width="1005" height="145" xlink:href="../repoimages/393186.jpg" preserveAspectRatio="none" transform="scale(0.9552238805970149,1) translate(-0,-0)  "></svg:image>\
                  </svg:svg>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-text8379352" style="position: absolute; left: 25px; top: 370px; width: 705px; height: 336px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8379352" data-stencil-id="text8379352">\
         <div title="">\
            <div style="height: 341px;width:715px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We apply innovative solutions to today\'s complex market research problems.<br /><br />You should expect your research team to help you solve your business challenges using custom solutions, not solutions that\
               <br />worked for someone else. At TRC, we offer expertise across many methodologies, and developed unique and innovative <br />solutions you can use to understand consumer choice and solve business problems: Bracket™ , TeXo™, Idea Mill™, Idea <br />Audit™ and Message Test Express™.<br /><br />Watch the videos to the left to see how these solutions could work for you.<br />Tell us about your innovation journey.<br /><br />Your business needs are unique. Your research experience should be, too. Let TRC recommend the right research solution to\
               <br />help you:<br /><br />    Develop new products<br /><br />    Optimize pricing<br /><br />    Create stronger segmentation solutions<br /><br />    Exploit the value of your brand<br />    Gauge customer satisfaction and loyalty<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-tabbutton314326" style="position: absolute; left: 160px; top: 160px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton314326" data-stencil-id="tabbutton314326">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage2433315" x="-5" y="0" width="70" height="20" name="targetpage2433315" class="">\
                  <svg:path id="__containerId__-page0001-layer-tabbutton314326_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page0001-layer-tabbutton314326_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page0001-layer-tabbutton314326div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page0001-layer-tabbutton314326\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page0001-layer-tabbutton314326\', \'result\');">\
               				About us\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page0001-layer-tabbutton314326\', \'interaction2832345\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action7574379\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction888419\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page2433315\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page0001-layer-tabbutton4583639" style="position: absolute; left: 275px; top: 160px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton4583639" data-stencil-id="tabbutton4583639">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage2151035" x="-5" y="0" width="70" height="20" name="targetpage2151035" class="">\
                  <svg:path id="__containerId__-page0001-layer-tabbutton4583639_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page0001-layer-tabbutton4583639_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page0001-layer-tabbutton4583639div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page0001-layer-tabbutton4583639\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page0001-layer-tabbutton4583639\', \'result\');">\
               				Log in\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page0001-layer-tabbutton4583639\', \'interaction9747427\', \
		{\
		\
			\'id\': \'action2087480\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'hover\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction9162746\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page2151035\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page0001-layer-clickArea3907309" style="position: absolute; left: 40px; top: 715px; width: 680px; height: 215px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="clickArea3907309" data-stencil-id="clickArea3907309">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 215px; width:680px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 215px;width:680px;" width="680" height="215" viewBox="0 0 680 215">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="680" height="215" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-text3054332" style="position: absolute; left: 70px; top: 765px; width: 150px; height: 51px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3054332" data-stencil-id="text3054332">\
         <div title="">\
            <div style="height: 56px;width:160px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Business to Business <br />article (read here)<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-text988274" style="position: absolute; left: 65px; top: 730px; width: 125px; height: 30px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text988274" data-stencil-id="text988274">\
         <div title="">\
            <div style="height: 35px;width:135px;font-size:1.56em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Uudiste portaal<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page0001-layer-tabbutton9503754" style="position: absolute; left: 395px; top: 160px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton9503754" data-stencil-id="tabbutton9503754">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage9084005" x="-5" y="0" width="70" height="20" name="targetpage9084005" class="">\
                  <svg:path id="__containerId__-page0001-layer-tabbutton9503754_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page0001-layer-tabbutton9503754_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page0001-layer-tabbutton9503754div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page0001-layer-tabbutton9503754\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page0001-layer-tabbutton9503754\', \'result\');">\
               				LK\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page0001-layer-tabbutton9503754\', \'interaction436172\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action2176205\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction8116368\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page9084005\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');