rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page5012072-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page5012072" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page5012072-layer-text8534321" style="position: absolute; left: 85px; top: 65px; width: 355px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8534321" data-stencil-id="text8534321">\
         <div title="">\
            <div style="height: 71px;width:365px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Analytic Techniques<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-image4674436" style="position: absolute; left: 615px; top: 150px; width: 80px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image4674436" data-stencil-id="image4674436">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 60px;width:80px;" width="80" height="60">\
               <svg:g width="80" height="60"><svg:path id="id" d="M 2.00, 2.00 Q 14.67, 1.09, 27.33, 1.44 Q 40.00, 2.00, 52.67, 1.17 Q 65.33, 0.63, 78.41, 1.59 Q 78.99,\
                  15.67, 79.55, 29.78 Q 79.34, 43.91, 78.76, 58.76 Q 65.60, 58.84, 52.74, 58.56 Q 40.06, 58.96, 27.39, 59.89 Q 14.69, 59.47,\
                  0.93, 59.07 Q 1.42, 44.19, 1.02, 30.14 Q 2.00, 16.00, 2.00, 2.00" style="fill:white;stroke-width:1.5;" class="svg_unselected_element"/><svg:path d="M 2.00, 2.00 Q 12.63, 7.46, 22.23, 14.33 Q 31.79, 21.25, 41.17, 28.41 Q 50.56, 35.57, 60.22, 42.34 Q 68.50, 51.00,\
                  78.00, 58.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 2.00, 58.00 Q 10.52, 49.29, 20.67, 42.84 Q 31.00, 36.65, 40.98, 29.97 Q 50.33, 22.42, 60.33, 15.76 Q 70.25,\
                  9.00, 80.00, 2.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-text3647113" style="position: absolute; left: 110px; top: 160px; width: 300px; height: 186px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3647113" data-stencil-id="text3647113">\
         <div title="">\
            <div style="height: 191px;width:310px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, <br />sed diam nonumy eirmod tempor invidunt ut labore et <br />dolore magna aliquyam erat, sed diam voluptua. At <br />vero eos et accusam et justo duo dolores et ea rebum. <br />Stet clita kasd gubergren, no sea takimata sanctus est <br />Lorem ipsum dolor sit amet. Lorem ipsum dolor sit <br />amet, consetetur sadipscing elitr, sed diam nonumy <br />eirmod tempor invidunt ut labore et dolore magna <br />aliquyam erat, sed diam voluptua. At vero eos et <br />accusam et justo duo dolores et ea rebum. Stet clita <br />kasd gubergren, no sea takimata sanctus est Lorem <br />ipsum dolor sit amet.<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-chart8081007" style="position: absolute; left: 575px; top: 290px; width: 180px; height: 150px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="chart8081007" data-stencil-id="chart8081007">\
         <div title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:180px;" viewBox="0 0 180 150" width="180" height="150">\
               <svg:g width="180" height="150">\
                  <svg:g transform="scale(1, 1)"><svg:path id="defaultID" d="M 0.00, 0.00 Q 10.00, -1.08, 20.00, -1.08 Q 30.00, -1.23, 40.00, -1.24 Q 50.00, -1.22, 60.00,\
                     -1.03 Q 70.00, -1.16, 80.00, -1.28 Q 90.00, -1.31, 100.00, -1.25 Q 110.00, -1.53, 120.00, -1.07 Q 130.00, -1.22, 140.00, -1.28\
                     Q 150.00, -1.36, 160.00, -1.12 Q 170.00, -1.21, 180.65, -0.65 Q 181.00, 10.38, 181.06, 21.28 Q 180.87, 32.08, 181.40, 42.81\
                     Q 180.96, 53.56, 180.50, 64.28 Q 180.52, 75.00, 180.68, 85.71 Q 180.69, 96.43, 180.98, 107.14 Q 181.28, 117.86, 181.23, 128.57\
                     Q 180.58, 139.29, 180.17, 150.17 Q 170.12, 150.37, 160.08, 150.55 Q 150.04, 150.66, 140.02, 150.59 Q 130.01, 150.41, 120.01,\
                     151.14 Q 110.00, 150.29, 100.00, 151.19 Q 90.00, 151.15, 80.00, 150.66 Q 70.00, 151.26, 60.00, 151.09 Q 50.00, 151.29, 40.00,\
                     151.35 Q 30.00, 151.69, 20.00, 151.28 Q 10.00, 151.17, -0.62, 150.62 Q -0.96, 139.61, -0.55, 128.65 Q -0.80, 117.91, -0.70,\
                     107.17 Q -0.54, 96.44, -1.52, 85.73 Q -1.09, 75.00, -1.94, 64.29 Q -1.71, 53.57, -1.70, 42.86 Q -1.37, 32.14, -1.04, 21.43\
                     Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;" class="svg_unselected_element"/>\
                     <svg:g style="stroke:black;fill:none;stroke-width:1px;"><svg:path d="M 9.00, 3.00 Q 10.19, 14.42, 9.72, 25.83 Q 9.50, 37.25, 9.62, 48.67 Q 9.62, 60.08, 9.94, 71.50 Q 9.14, 82.92,\
                        9.68, 94.33 Q 9.76, 105.75, 9.69, 117.17 Q 10.31, 128.58, 9.84, 139.16 Q 19.91, 138.76, 30.01, 139.94 Q 40.50, 139.93, 51.02,\
                        139.40 Q 61.52, 138.68, 72.01, 139.01 Q 82.50, 138.96, 93.00, 138.92 Q 103.50, 139.07, 114.00, 138.41 Q 124.50, 138.11, 135.00,\
                        137.83 Q 145.50, 137.76, 156.00, 138.06 Q 166.50, 140.00, 177.00, 140.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 168.00, 135.00 Q 174.02, 135.46, 178.99, 140.00 Q 173.00, 142.50, 168.00, 145.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 13.00 Q 4.74, 7.12, 9.00, 2.16 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 19.00, 63.00 Q 28.50, 61.48, 38.68, 62.32 Q 39.45, 75.35, 38.64, 88.58 Q 38.38, 101.47, 39.37, 114.29 Q 38.54,\
                        127.16, 38.25, 140.25 Q 28.44, 139.82, 18.88, 140.12 Q 18.55, 127.29, 18.25, 114.42 Q 18.81, 101.51, 18.79, 88.67 Q 19.00,\
                        75.83, 19.00, 63.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 47.00, 47.00 Q 56.50, 46.76, 65.80, 47.20 Q 65.34, 58.85, 64.90, 70.41 Q 65.20, 81.93, 64.63, 93.54 Q 64.78,\
                        105.14, 64.00, 116.77 Q 65.23, 128.38, 65.45, 139.45 Q 56.12, 138.86, 47.21, 139.79 Q 47.06, 128.36, 46.57, 116.80 Q 47.18,\
                        105.12, 47.53, 93.49 Q 48.37, 81.86, 47.11, 70.25 Q 47.00, 58.62, 47.00, 47.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 76.00, 56.00 Q 85.50, 54.74, 95.70, 55.30 Q 95.30, 66.40, 96.04, 76.85 Q 95.20, 87.49, 95.11, 98.00 Q 95.41,\
                        108.49, 96.30, 118.99 Q 96.16, 129.50, 95.22, 140.22 Q 85.49, 139.96, 75.89, 140.11 Q 76.06, 129.48, 76.55, 118.94 Q 76.27,\
                        108.49, 75.91, 98.00 Q 75.59, 87.50, 74.92, 77.01 Q 76.00, 66.50, 76.00, 56.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 104.00, 89.00 Q 113.50, 88.67, 123.24, 88.76 Q 123.39, 101.62, 123.75, 114.39 Q 123.86, 127.19, 123.36, 140.36\
                        Q 113.69, 140.59, 103.63, 140.35 Q 103.30, 127.44, 102.98, 114.61 Q 104.00, 101.75, 104.00, 89.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 133.00, 31.00 Q 142.50, 28.49, 153.27, 29.73 Q 153.72, 41.33, 153.86, 52.53 Q 154.17, 63.56, 153.94, 74.54\
                        Q 153.86, 85.47, 153.85, 96.39 Q 153.66, 107.29, 153.65, 118.20 Q 153.61, 129.10, 152.58, 140.58 Q 142.73, 140.69, 132.58,\
                        140.42 Q 132.23, 129.31, 131.87, 118.33 Q 131.50, 107.38, 131.83, 96.43 Q 132.06, 85.51, 132.18, 74.60 Q 132.04, 63.70, 131.98,\
                        52.80 Q 133.00, 41.90, 133.00, 31.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-tabbutton9107854" style="position: absolute; left: 365px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton9107854" data-stencil-id="tabbutton9107854">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage0001" width="78" height="20" name="targetpage0001" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 6.28, 20.50, 6.32, 19.00 Q 6.73, 17.50, 7.08, 16.02 Q 7.88, 15.14, 8.23, 14.10 Q 8.20, 12.86,\
                     8.57, 11.58 Q 9.87, 11.33, 11.03, 11.05 Q 12.41, 11.24, 12.99, 9.97 Q 14.36, 9.15, 15.87, 8.31 Q 28.14, 7.84, 40.43, 7.43\
                     Q 52.73, 7.96, 65.09, 8.40 Q 66.59, 9.13, 68.07, 9.82 Q 68.98, 10.54, 69.85, 11.33 Q 70.90, 11.70, 72.98, 11.01 Q 74.15, 11.81,\
                     74.62, 13.03 Q 74.95, 14.20, 75.90, 15.17 Q 76.61, 16.69, 77.22, 18.59 Q 77.25, 20.30, 76.16, 23.08 Q 63.76, 23.27, 51.86,\
                     23.38 Q 40.11, 23.72, 28.38, 23.33 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 5.76, 17.50, 5.69, 13.00 Q 5.59, 11.50, 5.50, 9.65 Q 6.37, 8.59, 6.36, 7.29 Q 7.35, 6.47, 8.25,\
                     5.27 Q 9.26, 4.47, 10.41, 4.02 Q 11.00, 2.69, 12.19, 2.14 Q 13.99, 2.18, 15.74, 1.57 Q 28.14, 1.81, 40.47, 2.25 Q 52.72, 1.52,\
                     65.16, 1.96 Q 66.77, 2.36, 68.21, 3.41 Q 69.64, 3.01, 70.88, 3.11 Q 71.86, 3.72, 73.29, 4.70 Q 73.75, 6.10, 73.99, 7.40 Q\
                     74.36, 8.53, 75.13, 9.51 Q 75.57, 11.09, 75.80, 12.85 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage0001" name="targetpage0001" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton9107854\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton9107854\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton9107854_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton9107854_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton9107854\', \'interaction7530483\', \
		{\
		\
			\'id\': \'action3812381\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction8000899\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page5012072-layer-tabbutton5747663" style="position: absolute; left: 455px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton5747663" data-stencil-id="tabbutton5747663">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage2433315" width="78" height="20" name="targetpage2433315" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 6.68, 20.50, 6.63, 19.00 Q 6.49, 17.50, 6.50, 15.88 Q 7.02, 14.82, 8.02, 14.01 Q 7.49, 12.53,\
                     8.76, 11.76 Q 9.66, 11.02, 10.73, 10.56 Q 12.07, 10.62, 13.17, 10.40 Q 14.37, 9.17, 15.76, 7.70 Q 28.10, 7.32, 40.47, 8.28\
                     Q 52.75, 8.78, 65.13, 8.14 Q 66.60, 9.10, 68.07, 9.81 Q 68.76, 11.06, 69.65, 11.76 Q 70.71, 12.11, 71.02, 13.00 Q 72.34, 13.11,\
                     73.20, 13.88 Q 74.05, 14.70, 75.36, 15.41 Q 75.48, 17.12, 76.76, 18.67 Q 76.38, 20.38, 75.44, 22.40 Q 63.39, 22.16, 51.67,\
                     22.05 Q 40.02, 22.30, 28.36, 22.70 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 7.87, 17.50, 7.24, 13.00 Q 7.41, 11.50, 7.11, 10.03 Q 6.99, 8.82, 7.68, 7.86 Q 7.00, 6.30, 8.45,\
                     5.47 Q 9.27, 4.49, 10.68, 4.46 Q 12.13, 4.74, 13.44, 5.02 Q 14.76, 4.17, 15.90, 2.49 Q 28.27, 3.20, 40.52, 3.47 Q 52.76, 3.53,\
                     65.09, 2.42 Q 66.66, 2.82, 68.19, 3.49 Q 68.86, 4.83, 70.12, 4.74 Q 71.18, 5.12, 71.85, 6.15 Q 72.89, 6.72, 73.09, 7.94 Q\
                     74.28, 8.57, 74.97, 9.58 Q 75.40, 11.16, 75.21, 12.96 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage2433315" name="targetpage2433315" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton5747663\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton5747663\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton5747663_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">About us\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton5747663_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">About us\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton5747663\', \'interaction4331643\', \
		{\
		\
			\'id\': \'action2456884\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction7720337\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page2433315\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');