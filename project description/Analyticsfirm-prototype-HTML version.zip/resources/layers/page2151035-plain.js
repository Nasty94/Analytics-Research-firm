rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page2151035-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page2151035" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page2151035-layer-text2326661" style="position: absolute; left: 65px; top: 45px; width: 475px; height: 87px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text2326661" data-stencil-id="text2326661">\
         <div title="">\
            <div style="height: 92px;width:485px;font-size:2.67em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Your profile<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2151035-layer-text3068028" style="position: absolute; left: 75px; top: 395px; width: 36px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3068028" data-stencil-id="text3068028">\
         <div title="">\
            <div style="height: 26px;width:46px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">E-mail<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2151035-layer-textinput178263" style="position: absolute; left: 195px; top: 385px; width: 150px; height: 20px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="textinput178263" data-stencil-id="textinput178263">\
         <div title=""><input id="__containerId__-page2151035-layer-textinput178263input" value="" style="width:148px;height:18px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-page2151035-layer-text5274626" style="position: absolute; left: 75px; top: 440px; width: 56px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text5274626" data-stencil-id="text5274626">\
         <div title="">\
            <div style="height: 26px;width:66px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Password<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2151035-layer-textinput7085469" style="position: absolute; left: 195px; top: 435px; width: 150px; height: 20px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="textinput7085469" data-stencil-id="textinput7085469">\
         <div title=""><input id="__containerId__-page2151035-layer-textinput7085469input" value="" style="width:148px;height:18px;padding: 0px;border-width:1px;" type="text" /></div>\
      </div>\
      <div id="__containerId__-page2151035-layer-checkbox5233230" style="position: absolute; left: 70px; top: 465px; width: 104px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="checkbox5233230" data-stencil-id="checkbox5233230">\
         <div style="font-size:1em;" xml:space="preserve" title="">\
            			\
            <nobr><label><input id="__containerId__-page2151035-layer-checkbox5233230input" style="padding-right:9px" type="checkbox" checked="true" />remember me</label></nobr>\
            		\
         </div>\
      </div>\
      <div id="__containerId__-page2151035-layer-image8375817" style="position: absolute; left: 50px; top: 170px; width: 755px; height: 160px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image8375817" data-stencil-id="image8375817">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 160px;width:755px;" width="755" height="160" viewBox="0 0 755 160">\
               <svg:g width="755" height="160">\
                  <svg:rect x="0" y="0" width="755" height="160" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="755" y2="160" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="160" x2="755" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2151035-layer-button1419873" style="position: absolute; left: 70px; top: 515px; width: 60px; height: 24px" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="button1419873" data-stencil-id="button1419873">\
         <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" title=""><button type="button" style="width:60px;height:24px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Log in<br /></button></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page2151035-layer-button1419873\', \'interaction8907669\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action8012591\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction3785465\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page8655174\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');