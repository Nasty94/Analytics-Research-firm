rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page2433315-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page2433315" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page2433315-layer-text9624493" style="position: absolute; left: -120px; top: -130px; width: 710px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9624493" data-stencil-id="text9624493">\
         <div title="">\
            <div style="height: 116px;width:720px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. TRC has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-image5111072" style="position: absolute; left: 55px; top: 105px; width: 730px; height: 225px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image5111072" data-stencil-id="image5111072">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 225px;width:730px;" width="730" height="225">\
               <svg:g width="730" height="225">\
                  <svg:svg x="1" y="1" width="728" height="223">\
                     <svg:image width="950" height="534" xlink:href="../repoimages/393179.jpg" preserveAspectRatio="none" transform="scale(0.7684210526315789,0.42134831460674155) translate(-0,-0)  "></svg:image>\
                  </svg:svg>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text9718962" style="position: absolute; left: 60px; top: 50px; width: 150px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9718962" data-stencil-id="text9718962">\
         <div title="">\
            <div style="height: 71px;width:160px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">About us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text3247859" style="position: absolute; left: 45px; top: 375px; width: 705px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3247859" data-stencil-id="text3247859">\
         <div title="">\
            <div style="height: 116px;width:715px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. We are has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-tabbutton7375897" style="position: absolute; left: 665px; top: 50px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton7375897" data-stencil-id="tabbutton7375897">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage0001" width="78" height="20" name="targetpage0001" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 6.96, 20.50, 6.85, 19.00 Q 6.83, 17.50, 6.65, 15.92 Q 7.00, 14.82, 7.49, 13.78 Q 7.82, 12.69,\
                     8.42, 11.44 Q 9.44, 10.72, 10.60, 10.34 Q 11.63, 9.83, 12.66, 9.23 Q 14.16, 8.62, 15.80, 7.89 Q 28.19, 8.35, 40.46, 8.02 Q\
                     52.72, 7.75, 65.14, 8.10 Q 66.79, 8.32, 68.25, 9.31 Q 69.18, 10.07, 70.55, 9.82 Q 71.21, 11.07, 72.88, 11.11 Q 73.53, 12.26,\
                     73.82, 13.51 Q 74.50, 14.45, 75.23, 15.47 Q 75.83, 16.99, 75.58, 18.89 Q 74.79, 20.52, 75.44, 22.41 Q 63.68, 23.04, 51.84,\
                     23.19 Q 40.05, 22.69, 28.35, 22.49 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 5.83, 17.50, 6.42, 13.00 Q 6.64, 11.50, 7.19, 10.04 Q 6.80, 8.75, 7.50, 7.78 Q 8.85, 7.16, 9.85,\
                     6.83 Q 10.28, 5.89, 11.07, 5.12 Q 11.99, 4.49, 12.83, 3.61 Q 14.21, 2.75, 15.97, 2.81 Q 28.23, 2.79, 40.56, 4.24 Q 52.76,\
                     3.46, 64.92, 3.51 Q 66.38, 4.00, 67.86, 4.39 Q 68.96, 4.59, 70.27, 4.42 Q 71.25, 4.97, 73.15, 4.84 Q 73.66, 6.17, 74.64, 7.01\
                     Q 74.04, 8.71, 74.00, 10.00 Q 75.38, 11.16, 76.25, 12.77 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage0001" name="targetpage0001" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton7375897\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton7375897\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton7375897_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton7375897_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page2433315-layer-tabbutton7375897\', \'interaction83474\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action9748501\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction9193128\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page2433315-layer-menu3178041" style="position: absolute; left: 425px; top: 55px; width: 200px; height: 20px" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="menu3178041" data-stencil-id="menu3178041">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 22px;width:200px;" width="200" height="20"><svg:path d="M 2.00, 2.00 Q 12.89, 1.29, 23.78, 1.42 Q 34.67, 1.49, 45.56, 1.55 Q 56.44, 2.10, 67.33, 1.36 Q 78.22, 2.09,\
               89.11, 1.95 Q 100.00, 3.43, 110.89, 3.41 Q 121.78, 1.19, 132.67, 1.55 Q 143.56, 2.19, 154.44, 2.49 Q 165.33, 1.51, 176.22,\
               2.04 Q 187.11, 2.92, 197.53, 2.47 Q 196.99, 11.34, 197.58, 19.58 Q 187.30, 20.70, 176.36, 21.28 Q 165.35, 20.24, 154.47, 21.11\
               Q 143.55, 19.28, 132.67, 20.43 Q 121.78, 19.22, 110.89, 18.83 Q 100.00, 20.02, 89.11, 20.00 Q 78.22, 20.71, 67.33, 19.97 Q\
               56.44, 20.10, 45.56, 19.63 Q 34.67, 19.69, 23.78, 20.53 Q 12.89, 20.57, 1.87, 20.13 Q 2.00, 11.00, 2.00, 2.00" style=" fill:white;"\
               class="svg_unselected_element"/>\
            </svg:svg>\
            <div id="__containerId__-page2433315-layer-menu3178041-menu-container" class="yui-skin-sam" style="position:absolute;left: 2px;top: 2px;width:196px;height:16px;" title=""></div>\
         </div><script type="text/javascript">\
			rabbit.stencils.menu.setupMenu("__containerId__-page2433315-layer-menu3178041", \'[]\', \'horizontal\');\
		</script></div>\
      <div id="__containerId__-page2433315-layer-text3426985" style="position: absolute; left: 45px; top: 520px; width: 92px; height: 30px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3426985" data-stencil-id="text3426985">\
         <div title="">\
            <div style="height: 35px;width:102px;font-size:1.56em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Contact Us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-clickArea369997" style="position: absolute; left: 50px; top: 560px; width: 475px; height: 240px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="clickArea369997" data-stencil-id="clickArea369997">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 240px; width:475px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 240px;width:475px;" width="475" height="240" viewBox="0 0 475 240">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="475" height="240" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text8289121" style="position: absolute; left: 100px; top: 605px; width: 125px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8289121" data-stencil-id="text8289121">\
         <div title="">\
            <div style="height: 26px;width:135px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">siin on kontaktandmed<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');