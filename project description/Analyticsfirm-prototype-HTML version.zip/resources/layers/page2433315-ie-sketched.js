rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page2433315-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page2433315" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page2433315-layer-text9624493" style="position: absolute; left: -120px; top: -130px; width: 710px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9624493" data-stencil-id="text9624493">\
         <div title="">\
            <div style="height: 116px;width:720px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. TRC has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-image5111072" style="position: absolute; left: 55px; top: 105px; width: 730px; height: 225px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image5111072" data-stencil-id="image5111072">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 225px;width:730px;" width="730" height="225">\
               <svg:g width="730" height="225">\
                  <svg:svg x="1" y="1" width="728" height="223">\
                     <svg:image width="950" height="534" xlink:href="../repoimages/393179.jpg" preserveAspectRatio="none" transform="scale(0.7684210526315789,0.42134831460674155) translate(-0,-0)  "></svg:image>\
                  </svg:svg>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text9718962" style="position: absolute; left: 60px; top: 50px; width: 150px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9718962" data-stencil-id="text9718962">\
         <div title="">\
            <div style="height: 71px;width:160px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">About us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text3247859" style="position: absolute; left: 45px; top: 375px; width: 705px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3247859" data-stencil-id="text3247859">\
         <div title="">\
            <div style="height: 116px;width:715px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. We are has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-tabbutton7375897" style="position: absolute; left: 665px; top: 50px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton7375897" data-stencil-id="tabbutton7375897">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage0001" width="78" height="20" name="targetpage0001" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 5.29, 20.50, 5.25, 19.00 Q 5.09, 17.50, 5.51, 15.65 Q 5.98, 14.45, 6.40, 13.31 Q 6.90, 12.26,\
                     8.05, 11.08 Q 9.16, 10.34, 10.35, 9.92 Q 11.36, 9.33, 12.64, 9.17 Q 14.04, 8.30, 15.75, 7.67 Q 28.14, 7.77, 40.45, 7.99 Q\
                     52.73, 8.15, 65.18, 7.80 Q 66.55, 9.29, 68.07, 9.80 Q 69.36, 9.66, 70.22, 10.53 Q 71.24, 11.01, 71.91, 12.09 Q 72.85, 12.75,\
                     73.64, 13.61 Q 74.33, 14.54, 74.41, 15.82 Q 75.21, 17.23, 75.54, 18.90 Q 75.83, 20.42, 75.30, 22.28 Q 63.58, 22.74, 51.81,\
                     23.04 Q 40.06, 22.90, 28.39, 23.78 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 7.16, 17.50, 7.63, 13.00 Q 7.57, 11.50, 7.75, 10.18 Q 7.79, 9.10, 8.22, 8.09 Q 8.75, 7.12, 8.79,\
                     5.79 Q 10.17, 5.74, 10.58, 4.31 Q 11.76, 4.07, 13.01, 4.03 Q 14.55, 3.63, 15.97, 2.83 Q 28.17, 2.16, 40.44, 1.71 Q 52.77,\
                     4.05, 65.01, 2.91 Q 66.71, 2.62, 68.41, 2.87 Q 69.04, 4.42, 70.09, 4.81 Q 71.13, 5.24, 71.87, 6.13 Q 72.51, 7.00, 73.42, 7.75\
                     Q 74.31, 8.56, 74.19, 9.92 Q 74.80, 11.39, 76.15, 12.79 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage0001" name="targetpage0001" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton7375897\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton7375897\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton7375897_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton7375897_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page2433315-layer-tabbutton7375897\', \'interaction83474\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action9748501\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction9193128\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page2433315-layer-menu3178041" style="position: absolute; left: 425px; top: 55px; width: 200px; height: 20px" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="menu3178041" data-stencil-id="menu3178041">\
         <div>\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 22px;width:200px;" width="200" height="20"><svg:path d="M 2.00, 2.00 Q 12.89, 0.39, 23.78, 1.07 Q 34.67, 1.33, 45.56, 2.07 Q 56.44, 1.95, 67.33, 1.82 Q 78.22, 2.85,\
               89.11, 2.06 Q 100.00, 2.12, 110.89, 2.15 Q 121.78, 2.16, 132.67, 1.68 Q 143.56, 1.36, 154.44, 1.96 Q 165.33, 0.77, 176.22,\
               1.17 Q 187.11, 1.02, 198.22, 1.78 Q 198.80, 10.73, 198.14, 20.14 Q 187.16, 20.17, 176.20, 19.81 Q 165.33, 19.84, 154.45, 20.03\
               Q 143.56, 20.55, 132.67, 21.25 Q 121.78, 19.20, 110.89, 19.82 Q 100.00, 20.37, 89.11, 21.75 Q 78.22, 21.41, 67.33, 21.49 Q\
               56.44, 20.60, 45.56, 21.58 Q 34.67, 20.52, 23.78, 19.98 Q 12.89, 20.64, 1.39, 20.61 Q 2.00, 11.00, 2.00, 2.00" style=" fill:white;"\
               class="svg_unselected_element"/>\
            </svg:svg>\
            <div id="__containerId__-page2433315-layer-menu3178041-menu-container" class="yui-skin-sam" style="position:absolute;left: 2px;top: 2px;width:196px;height:16px;" title=""></div>\
         </div><script type="text/javascript">\
			rabbit.stencils.menu.setupMenu("__containerId__-page2433315-layer-menu3178041", \'[]\', \'horizontal\');\
		</script></div>\
      <div id="__containerId__-page2433315-layer-text3426985" style="position: absolute; left: 45px; top: 520px; width: 92px; height: 30px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3426985" data-stencil-id="text3426985">\
         <div title="">\
            <div style="height: 35px;width:102px;font-size:1.56em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Contact Us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-clickArea369997" style="position: absolute; left: 50px; top: 560px; width: 475px; height: 240px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="clickArea369997" data-stencil-id="clickArea369997">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 240px; width:475px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 240px;width:475px;" width="475" height="240" viewBox="0 0 475 240">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="475" height="240" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text8289121" style="position: absolute; left: 100px; top: 605px; width: 125px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8289121" data-stencil-id="text8289121">\
         <div title="">\
            <div style="height: 26px;width:135px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">siin on kontaktandmed<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');