rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page5012072-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page5012072" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page5012072-layer-text8534321" style="position: absolute; left: 85px; top: 65px; width: 355px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8534321" data-stencil-id="text8534321">\
         <div title="">\
            <div style="height: 71px;width:365px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Analytic Techniques<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-image4674436" style="position: absolute; left: 615px; top: 150px; width: 80px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image4674436" data-stencil-id="image4674436">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 60px;width:80px;" width="80" height="60">\
               <svg:g width="80" height="60"><svg:path id="id" d="M 2.00, 2.00 Q 14.67, 2.35, 27.33, 2.34 Q 40.00, 2.01, 52.67, 1.72 Q 65.33, 1.71, 78.50, 1.50 Q 78.67,\
                  15.78, 78.79, 29.89 Q 78.37, 43.98, 78.67, 58.67 Q 65.79, 59.42, 52.88, 59.56 Q 40.07, 59.12, 27.36, 59.03 Q 14.69, 59.31,\
                  1.42, 58.58 Q 0.77, 44.41, 1.15, 30.12 Q 2.00, 16.00, 2.00, 2.00" style="fill:white;stroke-width:1.5;" class="svg_unselected_element"/><svg:path d="M 2.00, 2.00 Q 12.04, 8.27, 21.59, 15.20 Q 31.11, 22.17, 40.67, 29.09 Q 50.22, 36.03, 59.86, 42.84 Q 68.50, 51.00,\
                  78.00, 58.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 2.00, 58.00 Q 11.43, 50.55, 21.27, 43.67 Q 31.46, 37.30, 41.04, 30.06 Q 50.95, 23.28, 61.14, 16.88 Q 70.25,\
                  9.00, 80.00, 2.00" style=" fill:none;" class="svg_unselected_element"/>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-text3647113" style="position: absolute; left: 110px; top: 160px; width: 300px; height: 186px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3647113" data-stencil-id="text3647113">\
         <div title="">\
            <div style="height: 191px;width:310px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, <br />sed diam nonumy eirmod tempor invidunt ut labore et <br />dolore magna aliquyam erat, sed diam voluptua. At <br />vero eos et accusam et justo duo dolores et ea rebum. <br />Stet clita kasd gubergren, no sea takimata sanctus est <br />Lorem ipsum dolor sit amet. Lorem ipsum dolor sit <br />amet, consetetur sadipscing elitr, sed diam nonumy <br />eirmod tempor invidunt ut labore et dolore magna <br />aliquyam erat, sed diam voluptua. At vero eos et <br />accusam et justo duo dolores et ea rebum. Stet clita <br />kasd gubergren, no sea takimata sanctus est Lorem <br />ipsum dolor sit amet.<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-chart8081007" style="position: absolute; left: 575px; top: 290px; width: 180px; height: 150px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="chart8081007" data-stencil-id="chart8081007">\
         <div title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:180px;" viewBox="0 0 180 150" width="180" height="150">\
               <svg:g width="180" height="150">\
                  <svg:g transform="scale(1, 1)"><svg:path id="defaultID" d="M 0.00, 0.00 Q 10.00, -1.13, 20.00, -1.40 Q 30.00, -1.52, 40.00, -1.81 Q 50.00, -1.94, 60.00,\
                     -1.31 Q 70.00, -1.87, 80.00, -1.93 Q 90.00, -2.19, 100.00, -2.29 Q 110.00, -2.16, 120.00, -1.34 Q 130.00, -1.07, 140.00, -1.75\
                     Q 150.00, -1.66, 160.00, -1.63 Q 170.00, -1.56, 180.86, -0.86 Q 181.31, 10.28, 181.80, 21.17 Q 181.52, 32.04, 181.37, 42.81\
                     Q 181.28, 53.55, 180.65, 64.28 Q 180.02, 75.00, 180.21, 85.71 Q 180.96, 96.43, 181.02, 107.14 Q 180.94, 117.86, 180.65, 128.57\
                     Q 180.41, 139.29, 180.41, 150.41 Q 170.11, 150.32, 160.02, 150.12 Q 149.98, 149.75, 140.02, 150.72 Q 130.01, 150.78, 120.01,\
                     150.96 Q 110.00, 150.89, 100.00, 150.73 Q 90.00, 151.60, 80.00, 150.15 Q 70.00, 150.86, 60.00, 150.60 Q 50.00, 151.08, 40.00,\
                     151.29 Q 30.00, 151.37, 20.00, 151.42 Q 10.00, 150.59, -0.20, 150.20 Q -0.27, 139.38, -0.14, 128.59 Q -0.02, 117.86, -0.62,\
                     107.16 Q 0.10, 96.43, -0.61, 85.72 Q -0.88, 75.00, -0.58, 64.29 Q -0.24, 53.57, -0.02, 42.86 Q 0.02, 32.14, 0.11, 21.43 Q\
                     0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;" class="svg_unselected_element"/>\
                     <svg:g style="stroke:black;fill:none;stroke-width:1px;"><svg:path d="M 9.00, 3.00 Q 10.38, 14.42, 9.11, 25.83 Q 8.16, 37.25, 8.65, 48.67 Q 8.78, 60.08, 8.55, 71.50 Q 8.94, 82.92,\
                        9.29, 94.33 Q 9.59, 105.75, 9.87, 117.17 Q 10.06, 128.58, 9.55, 139.45 Q 19.68, 139.45, 30.06, 139.61 Q 40.55, 139.25, 51.02,\
                        139.31 Q 61.51, 139.19, 72.01, 139.20 Q 82.50, 139.56, 93.00, 139.09 Q 103.50, 139.52, 114.00, 138.68 Q 124.50, 139.56, 135.00,\
                        139.21 Q 145.50, 138.89, 156.00, 139.53 Q 166.50, 140.00, 177.00, 140.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 168.00, 135.00 Q 173.59, 136.33, 178.40, 140.00 Q 173.00, 142.50, 168.00, 145.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 13.00 Q 5.73, 7.62, 9.00, 2.57 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 19.00, 63.00 Q 28.50, 60.76, 38.82, 62.18 Q 39.71, 75.26, 39.03, 88.52 Q 39.26, 101.42, 39.76, 114.28 Q 38.71,\
                        127.16, 38.26, 140.26 Q 28.59, 140.26, 18.65, 140.35 Q 18.50, 127.30, 17.75, 114.47 Q 18.04, 101.55, 18.50, 88.68 Q 19.00,\
                        75.83, 19.00, 63.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 47.00, 47.00 Q 56.50, 47.23, 65.92, 47.08 Q 65.69, 58.73, 65.32, 70.35 Q 64.69, 81.96, 65.68, 93.51 Q 65.47,\
                        105.13, 66.56, 116.75 Q 66.18, 128.37, 65.95, 139.95 Q 56.62, 140.37, 46.53, 140.47 Q 46.52, 128.51, 47.39, 116.71 Q 46.52,\
                        105.15, 46.19, 93.52 Q 46.06, 81.89, 46.59, 70.25 Q 47.00, 58.62, 47.00, 47.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 76.00, 56.00 Q 85.50, 55.41, 95.39, 55.61 Q 95.50, 66.33, 95.62, 76.91 Q 95.94, 87.44, 95.98, 97.97 Q 96.16,\
                        108.48, 96.68, 118.99 Q 96.46, 129.49, 95.80, 140.80 Q 85.89, 141.19, 75.48, 140.52 Q 75.20, 129.72, 75.08, 119.10 Q 74.40,\
                        108.58, 74.23, 98.04 Q 74.58, 87.52, 74.61, 77.01 Q 76.00, 66.50, 76.00, 56.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 104.00, 89.00 Q 113.50, 88.30, 123.12, 88.88 Q 123.20, 101.68, 122.46, 114.58 Q 122.82, 127.26, 123.13, 140.13\
                        Q 113.42, 139.75, 103.95, 140.04 Q 104.60, 127.09, 103.47, 114.56 Q 104.00, 101.75, 104.00, 89.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 133.00, 31.00 Q 142.50, 29.77, 152.55, 30.45 Q 152.57, 41.71, 152.23, 52.77 Q 152.59, 63.66, 151.69, 74.61\
                        Q 152.19, 85.50, 151.44, 96.40 Q 152.77, 107.30, 151.77, 118.20 Q 151.09, 129.10, 151.26, 139.26 Q 142.34, 139.53, 132.98,\
                        140.02 Q 133.79, 128.89, 134.00, 118.09 Q 132.70, 107.32, 132.32, 96.42 Q 132.49, 85.51, 133.65, 74.60 Q 134.02, 63.70, 134.39,\
                        52.80 Q 133.00, 41.90, 133.00, 31.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-tabbutton9107854" style="position: absolute; left: 365px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton9107854" data-stencil-id="tabbutton9107854">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage0001" width="78" height="20" name="targetpage0001" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 8.02, 20.50, 7.89, 19.00 Q 7.79, 17.50, 6.84, 15.96 Q 6.51, 14.64, 7.60, 13.83 Q 8.04, 12.79,\
                     8.41, 11.42 Q 9.31, 10.54, 10.52, 10.21 Q 11.80, 10.13, 12.77, 9.47 Q 14.10, 8.46, 15.69, 7.30 Q 28.15, 7.85, 40.42, 7.18\
                     Q 52.73, 8.19, 65.20, 7.70 Q 66.72, 8.59, 68.44, 8.80 Q 69.49, 9.37, 70.67, 9.56 Q 71.99, 9.46, 73.26, 10.73 Q 73.93, 11.97,\
                     73.96, 13.42 Q 74.87, 14.25, 75.29, 15.44 Q 75.09, 17.27, 75.70, 18.87 Q 75.78, 20.43, 75.75, 22.69 Q 63.24, 21.73, 51.63,\
                     21.71 Q 39.98, 21.71, 28.35, 22.63 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 5.22, 17.50, 5.19, 13.00 Q 6.89, 11.50, 6.20, 9.81 Q 8.50, 9.36, 8.88, 8.38 Q 7.68, 6.62, 8.23,\
                     5.25 Q 9.11, 4.27, 11.02, 5.04 Q 12.24, 4.93, 13.16, 4.38 Q 14.30, 2.97, 15.89, 2.40 Q 28.24, 2.93, 40.49, 2.87 Q 52.73, 2.29,\
                     65.16, 1.95 Q 66.74, 2.51, 68.17, 3.53 Q 69.27, 3.87, 70.41, 4.11 Q 71.31, 4.86, 72.60, 5.39 Q 73.54, 6.25, 74.40, 7.16 Q\
                     74.55, 8.42, 75.22, 9.47 Q 75.79, 11.01, 76.49, 12.72 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage0001" name="targetpage0001" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton9107854\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton9107854\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton9107854_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton9107854_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Home\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton9107854\', \'interaction7530483\', \
		{\
		\
			\'id\': \'action3812381\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction8000899\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page5012072-layer-tabbutton5747663" style="position: absolute; left: 455px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton5747663" data-stencil-id="tabbutton5747663">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 31px;width:81px;" width="75" height="26">\
               <svg:g id="targetpage2433315" width="78" height="20" name="targetpage2433315" class="">\
                  <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 22.00 Q 6.77, 20.50, 7.05, 19.00 Q 7.61, 17.50, 6.95, 15.99 Q 7.25, 14.91, 8.30, 14.13 Q 9.02, 13.24,\
                     8.63, 11.64 Q 9.62, 10.98, 10.32, 9.87 Q 11.61, 9.79, 12.86, 9.67 Q 14.51, 9.52, 16.07, 9.38 Q 28.25, 9.01, 40.50, 8.89 Q\
                     52.74, 8.60, 65.06, 8.64 Q 66.62, 9.00, 68.23, 9.38 Q 69.17, 10.10, 70.23, 10.51 Q 71.14, 11.21, 72.45, 11.55 Q 73.28, 12.44,\
                     73.30, 13.82 Q 74.02, 14.72, 74.74, 15.68 Q 75.25, 17.21, 75.72, 18.87 Q 75.76, 20.43, 74.73, 21.75 Q 63.55, 22.64, 51.74,\
                     22.49 Q 40.08, 23.18, 28.36, 22.78 Q 16.67, 22.00, 5.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g class="bigSkechtedTab"><svg:path d="M 7.00, 22.00 Q 5.15, 17.50, 4.96, 13.00 Q 4.88, 11.50, 4.82, 9.49 Q 6.16, 8.51, 6.80, 7.48 Q 7.00, 6.30, 7.64,\
                     4.68 Q 9.50, 4.81, 10.35, 3.92 Q 11.24, 3.12, 12.64, 3.17 Q 13.89, 1.91, 15.73, 1.53 Q 28.10, 1.37, 40.42, 1.31 Q 52.72, 1.56,\
                     65.02, 2.86 Q 66.52, 3.43, 68.14, 3.62 Q 69.35, 3.70, 70.37, 4.21 Q 71.09, 5.32, 71.99, 6.02 Q 72.72, 6.84, 74.00, 7.40 Q\
                     74.09, 8.68, 74.91, 9.60 Q 75.29, 11.20, 75.95, 12.83 Q 75.00, 17.50, 75.00, 22.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
            <div id="targetpage2433315" name="targetpage2433315" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton5747663\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton5747663\', \'result\');" class="">\
               <div class="smallSkechtedTab">\
                  <div id="tabbutton5747663_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 14px;width:74px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve">About us\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
               <div class="bigSkechtedTab">\
                  <div id="tabbutton5747663_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 20px;width:77px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">About us\
                     \
                     <addMouseOverListener></addMouseOverListener>\
                     \
                     <addMouseOutListener></addMouseOutListener>\
                     						\
                  </div>\
               </div>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton5747663\', \'interaction4331643\', \
		{\
		\
			\'id\': \'action2456884\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction7720337\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page2433315\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');