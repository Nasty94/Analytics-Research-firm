rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page5012072-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page5012072" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page5012072-layer-text8534321" style="position: absolute; left: 85px; top: 65px; width: 355px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8534321" data-stencil-id="text8534321">\
         <div title="">\
            <div style="height: 71px;width:365px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Analytic Techniques<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-image4674436" style="position: absolute; left: 615px; top: 150px; width: 80px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image4674436" data-stencil-id="image4674436">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 60px;width:80px;" width="80" height="60" viewBox="0 0 80 60">\
               <svg:g width="80" height="60">\
                  <svg:rect x="0" y="0" width="80" height="60" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="80" y2="60" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="60" x2="80" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-text3647113" style="position: absolute; left: 110px; top: 160px; width: 300px; height: 186px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3647113" data-stencil-id="text3647113">\
         <div title="">\
            <div style="height: 191px;width:310px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, <br />sed diam nonumy eirmod tempor invidunt ut labore et <br />dolore magna aliquyam erat, sed diam voluptua. At <br />vero eos et accusam et justo duo dolores et ea rebum. <br />Stet clita kasd gubergren, no sea takimata sanctus est <br />Lorem ipsum dolor sit amet. Lorem ipsum dolor sit <br />amet, consetetur sadipscing elitr, sed diam nonumy <br />eirmod tempor invidunt ut labore et dolore magna <br />aliquyam erat, sed diam voluptua. At vero eos et <br />accusam et justo duo dolores et ea rebum. Stet clita <br />kasd gubergren, no sea takimata sanctus est Lorem <br />ipsum dolor sit amet.<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-chart8081007" style="position: absolute; left: 575px; top: 290px; width: 180px; height: 150px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="chart8081007" data-stencil-id="chart8081007">\
         <div title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:180px;" viewBox="0 0 180 150" width="180" height="150">\
               <svg:g width="180" height="150">\
                  <svg:g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1, 1)">\
                     <svg:rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></svg:rect>\
                     <svg:g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                        <svg:path d="M 9,3 L 9,140 L 177,140"></svg:path>\
                        <svg:path d="M 168,135 L 178,140 L 168,145"></svg:path>\
                        <svg:path d="M 4,13 L 9,3 L 14,13"></svg:path>\
                        <svg:rect width="19" height="77" x="19" y="63"></svg:rect>\
                        <svg:rect width="19" height="93" x="47" y="47"></svg:rect>\
                        <svg:rect width="19" height="84" x="76" y="56"></svg:rect>\
                        <svg:rect width="19" height="51" x="104" y="89"></svg:rect>\
                        <svg:rect width="19" height="109" x="133" y="31"></svg:rect>\
                     </svg:g>\
                  </svg:g>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page5012072-layer-tabbutton9107854" style="position: absolute; left: 365px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton9107854" data-stencil-id="tabbutton9107854">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage0001" x="-5" y="0" width="70" height="20" name="targetpage0001" class="">\
                  <svg:path id="__containerId__-page5012072-layer-tabbutton9107854_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page5012072-layer-tabbutton9107854_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page5012072-layer-tabbutton9107854div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page5012072-layer-tabbutton9107854\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page5012072-layer-tabbutton9107854\', \'result\');">\
               				Home\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton9107854\', \'interaction7530483\', \
		{\
		\
			\'id\': \'action3812381\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction8000899\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page5012072-layer-tabbutton5747663" style="position: absolute; left: 455px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton5747663" data-stencil-id="tabbutton5747663">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage2433315" x="-5" y="0" width="70" height="20" name="targetpage2433315" class="">\
                  <svg:path id="__containerId__-page5012072-layer-tabbutton5747663_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page5012072-layer-tabbutton5747663_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page5012072-layer-tabbutton5747663div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page5012072-layer-tabbutton5747663\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page5012072-layer-tabbutton5747663\', \'result\');">\
               				About us\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page5012072-layer-tabbutton5747663\', \'interaction4331643\', \
		{\
		\
			\'id\': \'action2456884\'\
			\
				,\
			\
			\'trigger\': \'enter\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction7720337\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page2433315\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');