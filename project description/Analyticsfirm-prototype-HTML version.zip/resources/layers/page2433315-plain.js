rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page2433315-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page2433315" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page2433315-layer-text9624493" style="position: absolute; left: -120px; top: -130px; width: 710px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9624493" data-stencil-id="text9624493">\
         <div title="">\
            <div style="height: 116px;width:720px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. TRC has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-image5111072" style="position: absolute; left: 55px; top: 105px; width: 730px; height: 225px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image5111072" data-stencil-id="image5111072">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 225px;width:730px;" width="730" height="225" viewBox="0 0 730 225">\
               <svg:g width="730" height="225">\
                  <svg:svg x="0" y="0" width="730" height="225">\
                     <svg:image width="950" height="534" xlink:href="../repoimages/393179.jpg" preserveAspectRatio="none" transform="scale(0.7684210526315789,0.42134831460674155) translate(-0,-0)  "></svg:image>\
                  </svg:svg>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text9718962" style="position: absolute; left: 60px; top: 50px; width: 150px; height: 66px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text9718962" data-stencil-id="text9718962">\
         <div title="">\
            <div style="height: 71px;width:160px;font-size:2em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">About us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text3247859" style="position: absolute; left: 45px; top: 375px; width: 705px; height: 111px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3247859" data-stencil-id="text3247859">\
         <div title="">\
            <div style="height: 116px;width:715px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">We are a research &amp; analytics firm, specializing in new product research, message optimization, pricing research, conjoint\
               <br />analysis, segmentation, brand equity, sat &amp; loyalty. We are has guided hundreds of clients through innovation challenges over\
               the <br />years and have learned from our own innovations along the way. Our market research experts are experienced and passionate,\
               <br />and collectively approach every assignment \'all in\' - no matter the size or complexity. We know the innovation journey can\
               feel <br />uncertain. So let us help you make more informed decisions. Even help you uncover ideas you may not have considered. We <br />specialize in tools and techniques such as discrete-choice conjoint, product configurator or max-diff that involve <br />respondent-friendly and engaging trade-offs. <br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-tabbutton7375897" style="position: absolute; left: 665px; top: 50px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton7375897" data-stencil-id="tabbutton7375897">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage0001" x="-5" y="0" width="70" height="20" name="targetpage0001" class="">\
                  <svg:path id="__containerId__-page2433315-layer-tabbutton7375897_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page2433315-layer-tabbutton7375897_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page2433315-layer-tabbutton7375897div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page2433315-layer-tabbutton7375897\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page2433315-layer-tabbutton7375897\', \'result\');">\
               				Home\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page2433315-layer-tabbutton7375897\', \'interaction83474\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action9748501\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction9193128\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page2433315-layer-menu3178041" style="position: absolute; left: 425px; top: 55px; width: 200px; height: 20px" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="menu3178041" data-stencil-id="menu3178041">\
         <div class="yui-skin-sam  menu" style="width:200px;height:20px;" title="">\
            <div id="__containerId__-page2433315-layer-menu3178041-menu-container"></div>\
         </div><script type="text/javascript">\
			rabbit.stencils.menu.setupMenu("__containerId__-page2433315-layer-menu3178041", \'[]\', \'horizontal\');\
		</script></div>\
      <div id="__containerId__-page2433315-layer-text3426985" style="position: absolute; left: 45px; top: 520px; width: 92px; height: 30px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text3426985" data-stencil-id="text3426985">\
         <div title="">\
            <div style="height: 35px;width:102px;font-size:1.56em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">Contact Us<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-clickArea369997" style="position: absolute; left: 50px; top: 560px; width: 475px; height: 240px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="clickArea369997" data-stencil-id="clickArea369997">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 240px; width:475px; cursor:pointer;">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 240px;width:475px;" width="475" height="240" viewBox="0 0 475 240">\
               <svg:a>\
                  <svg:rect x="0" y="0" width="475" height="240" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
               </svg:a>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page2433315-layer-text8289121" style="position: absolute; left: 100px; top: 605px; width: 125px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8289121" data-stencil-id="text8289121">\
         <div title="">\
            <div style="height: 26px;width:135px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">siin on kontaktandmed<br /></div>\
         </div>\
      </div>\
   </div>\
</div>');