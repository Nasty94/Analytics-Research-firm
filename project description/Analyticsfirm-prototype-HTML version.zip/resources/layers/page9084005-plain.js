rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page9084005-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page9084005" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page9084005-layer-text2411046" style="position: absolute; left: 65px; top: 70px; width: 39px; height: 47px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text2411046" data-stencil-id="text2411046">\
         <div title="">\
            <div style="height: 52px;width:49px;font-size:2.67em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">LK<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page9084005-layer-image4649811" style="position: absolute; left: 375px; top: 50px; width: 400px; height: 260px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image4649811" data-stencil-id="image4649811">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 260px;width:400px;" width="400" height="260" viewBox="0 0 400 260">\
               <svg:g width="400" height="260">\
                  <svg:rect x="0" y="0" width="400" height="260" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="400" y2="260" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="260" x2="400" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page9084005-layer-text5759000" style="position: absolute; left: 40px; top: 140px; width: 300px; height: 21px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text5759000" data-stencil-id="text5759000">\
         <div title="">\
            <div style="height: 26px;width:310px;font-size:1em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">info about firm owner<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page9084005-layer-tabbutton8325305" style="position: absolute; left: 245px; top: 65px; width: 70px; height: 20px" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="tabbutton8325305" data-stencil-id="tabbutton8325305">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 30px;width:80px;" width="70" height="25">\
               <svg:g id="targetpage0001" x="-5" y="0" width="70" height="20" name="targetpage0001" class="">\
                  <svg:path id="__containerId__-page9084005-layer-tabbutton8325305_small_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,25 L 5,25 L 5,15"></svg:path>\
                  <svg:path id="__containerId__-page9084005-layer-tabbutton8325305_big_path" width="70" height="20" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,25 L 5,10 C 5,0 15,0 15,0 L 65,0 C 75,0 75,10 75,10 L 75,25"></svg:path>\
               </svg:g>\
            </svg:svg>\
            <div id="__containerId__-page9084005-layer-tabbutton8325305div" class="helvetica-font" style="position: absolute; top: 4px; height: 20px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page9084005-layer-tabbutton8325305\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page9084005-layer-tabbutton8325305\', \'result\');">\
               				Home\
               				\
               <addMouseOverListener></addMouseOverListener>\
               				\
               <addMouseOutListener></addMouseOutListener>\
               			\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page9084005-layer-tabbutton8325305\', \'interaction5668715\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action1044953\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction4525076\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page0001\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');