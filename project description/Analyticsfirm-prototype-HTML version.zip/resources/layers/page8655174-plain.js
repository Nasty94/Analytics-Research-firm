rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page8655174-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page8655174" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page8655174-layer-text8785554" style="position: absolute; left: 55px; top: 350px; width: 138px; height: 47px" data-interactive-element-type="default.text" class="text stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="text8785554" data-stencil-id="text8785554">\
         <div title="">\
            <div style="height: 52px;width:148px;font-size:2.67em;line-height:1.2em;white-space: nowrap;" xml:space="preserve">My profile<br /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page8655174-layer-image783636" style="position: absolute; left: 55px; top: 405px; width: 1435px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="image783636" data-stencil-id="image783636">\
         <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
            <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 60px;width:1435px;" width="1435" height="60" viewBox="0 0 1435 60">\
               <svg:g width="1435" height="60">\
                  <svg:rect x="0" y="0" width="1435" height="60" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                  <svg:line x1="0" y1="0" x2="1435" y2="60" style="stroke:black; stroke-width:0.5;"></svg:line>\
                  <svg:line x1="0" y1="60" x2="1435" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
               </svg:g>\
            </svg:svg>\
         </div>\
      </div>\
      <div id="__containerId__-page8655174-layer-link537103" style="position: absolute; left: 55px; top: 520px; width: 58px; height: 19px" data-interactive-element-type="default.link" class="link pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link537103" data-stencil-id="link537103">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 19px;width:63px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;">my orders<br /></a></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page8655174-layer-link537103\', \'interaction4517159\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action5905287\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction8539539\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page4782509\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page8655174-layer-link7062958" style="position: absolute; left: 55px; top: 560px; width: 58px; height: 19px" data-interactive-element-type="default.link" class="link pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link7062958" data-stencil-id="link7062958">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 19px;width:63px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;">my orders<br /></a></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page8655174-layer-link7062958\', \'621818\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'365942\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'835741\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page4782509\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page8655174-layer-link6428087" style="position: absolute; left: 55px; top: 560px; width: 58px; height: 19px" data-interactive-element-type="default.link" class="link pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link6428087" data-stencil-id="link6428087">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 19px;width:63px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;">my orders<br /></a></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page8655174-layer-link6428087\', \'514983\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'653666\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'940372\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page4782509\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page8655174-layer-link2280137" style="position: absolute; left: 55px; top: 520px; width: 58px; height: 19px" data-interactive-element-type="default.link" class="link pidoco-clickable-element stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link2280137" data-stencil-id="link2280137">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 19px;width:63px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;">my orders<br /></a></div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page8655174-layer-link2280137\', \'465634\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'530028\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'681339\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'page4782509\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page8655174-layer-link1369170" style="position: absolute; left: 55px; top: 575px; width: 52px; height: 20px" data-interactive-element-type="default.link" class="link stencil mobile-interaction-potential-trigger&#xA;&#x9;&#x9;&#x9;" data-review-reference-id="link1369170" data-stencil-id="link1369170">\
         <div xmlns:pidoco="http://www.pidoco.com/util" style="position: absolute; left: 0px; top: 6px; height: 20px;width:57px;" title=""><a style="color:black;font-size:1em;white-space:nowrap;text-decoration: underline;">some link<br /></a></div>\
      </div>\
   </div>\
</div>');